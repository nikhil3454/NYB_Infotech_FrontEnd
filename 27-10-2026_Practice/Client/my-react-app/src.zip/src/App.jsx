import { useState, Component} from 'react'

import './App.css'
import {BrowserRouter,Routes,Route,Link} from 'react-router';
import {Home,About,Products} from "./pages" 
function Button({ children, onClick, className = "" }) {
  return (
    <button
      type="button"
      className={`custom-button ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
class Welcome extends Component {
  render() {
    return <h1>Welcome to React!</h1>;
  }
}

function App() {
  const [count, setCount] = useState(0);

  return (<>
    <BrowserRouter>
      <div className="app">
        <Header/>
        <h1 id="message">Hello World React</h1>
        <Content/>

        {/* Counter Section */}
        <section>
          <h2>Counter Application</h2>

          <h3>Count: {count}</h3>

          <Button onClick={() => setCount(count + 1)}>
            Increase
          </Button>

          <Button onClick={() => setCount(count - 1)}>
            Decrease
          </Button>

          <Button onClick={() => setCount(0)}>
            Reset
          </Button>
        </section>

        {/* Welcome Section */}
        <section>
          <h2>My First React App</h2>

          <p>I am learning React step by step.</p>

          <Button onClick={() => alert("Welcome!")}>
            Click Me
          </Button>
        </section>

        {/* Navigation Section */}
        <nav>
          <Link to="/">Home</Link>{" | "}
          <Link to="/about">About</Link>{" | "}
          <Link to="/products">Products</Link>
        </nav>

        {/* Page Routing */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/products" element={<Products />} />
        </Routes>
      <div>
      <h2>I am the parent component.</h2>
      <Child  name='nikhil'/>
      </div>
      <Footer/>
      </div>
    </BrowserRouter>
    </>
  );
}
function Child({name}) {
  return <p>I am the child component and my name is {name}.</p>;
}
function Header() {
  return <h1>My Website</h1>;
}

function Content() {
  return <p>Learn React step by step.</p>;
}

function Footer() {
  return <footer>Copyright 2026</footer>;
}

export default App
